import math

raiz_quadrada = math.sqrt(16)
potencia = math.pow(2, 3)

print("Raiz quadrada de 16:", raiz_quadrada)  # Saída: Raiz quadrada de 16: 4.0
print("2 elevado a 3:", potencia)             # Saída: 2 elevado a 3: 8.0
