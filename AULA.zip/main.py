import math

#exibe todas as funções de um módulo
print(dir(math))