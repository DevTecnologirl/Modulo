import os
os.remove("arquivo.txt")