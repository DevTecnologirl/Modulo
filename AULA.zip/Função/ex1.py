def boas_vindas(nomeDeUsuario):
  print("Bem-vindo(a),", nomeDeUsuario ,"à Ctrl+Play!")

boas_vindas("Rennan")