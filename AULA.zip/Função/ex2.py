def velocidade(distancia,tempo):
  print(distancia/tempo)
  
velocidade(tempo=5, distancia=100)