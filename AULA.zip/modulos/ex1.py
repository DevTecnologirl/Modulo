import math
# 2 elevado a 3
print(math.pow(2,3))

# arredondando valores
print(math.ceil(2.5))
print(math.trunc(2.5))
