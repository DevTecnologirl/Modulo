# matematica.py

def soma(x, y):
    return x + y

def subtracao(x, y):
    return x - y
