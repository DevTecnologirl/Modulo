# main.py

import matematica

resultado_soma = matematica.soma(10, 5)
resultado_subtracao = matematica.subtracao(10, 5)

print("Soma:", resultado_soma)          # Saída: Soma: 15
print("Subtração:", resultado_subtracao)  # Saída: Subtração: 5
